#ifndef SNAKEGAME_H
#define SNAKEGAME_H

#include <iostream>
#include <fstream>
#include <memory>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>

class BaseGame {
public:
    virtual void Setup() = 0;
    virtual void Draw() = 0;
    virtual void Input() = 0;
    virtual void Logic() = 0;
    virtual bool IsGameOver() const = 0;
    virtual int GetScore() const = 0;
    virtual int GetSpeed() const = 0;
    virtual unsigned char* GetScreenBuffer() const = 0;
    virtual ~BaseGame() {}
};

class SnakeGame : public BaseGame {
private:
    int snakeX, snakeY, fruitX, fruitY, score;
    std::vector<std::pair<int, int>> tail;
    enum class Direction { STOP = 0, LEFT, RIGHT, UP, DOWN };
    Direction dir;
    bool gameOver;
    int speed;
    int growthRate;
    std::unique_ptr<unsigned char[]> screenBuffer;

public:
    SnakeGame();
    void Setup() override;
    void Draw() override;
    void Input() override;
    void Logic() override;
    bool IsGameOver() const override;
    int GetScore() const override;
    int GetSpeed() const override;
    unsigned char* GetScreenBuffer() const override;
    void SaveGame(const std::string& filename) const;
    void LoadGame(const std::string& filename);
};

#endif // SNAKEGAME_H
