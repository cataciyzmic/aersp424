#include "SnakeGame.h"
#include "GameUtils.h"

const int width = 20;
const int height = 20;

SnakeGame::SnakeGame() : speed(100), growthRate(1) {
    screenBuffer = std::make_unique<unsigned char[]>(width * height);
}

void SnakeGame::Setup() {
    gameOver = false;
    dir = Direction::STOP;
    snakeX = width / 2;
    snakeY = height / 2;
    fruitX = rand() % width;
    fruitY = rand() % height;
    score = 0;
    std::fill_n(screenBuffer.get(), width * height, 0);
}

void SnakeGame::Draw() {
    system("clear");
    for (int i = 0; i < width + 2; i++)
        std::cout << "#";
    std::cout << std::endl;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            if (j == 0)
                std::cout << "#";
            if (i == snakeY && j == snakeX)
                std::cout << "O";
            else if (i == fruitY && j == fruitX)
                std::cout << "F";
            else {
                bool printTail = false;
                for (auto const &pos : tail) {
                    if (pos.first == j && pos.second == i) {
                        std::cout << "o";
                        printTail = true;
                        screenBuffer[i * width + j] = 1;
                    }
                }
                if (!printTail) {
                    std::cout << " ";
                    screenBuffer[i * width + j] = 0;
                }
            }
            if (j == width - 1)
                std::cout << "#";
        }
        std::cout << std::endl;
    }

    for (int i = 0; i < width + 2; i++)
        std::cout << "#";
    std::cout << std::endl;
    std::cout << "Score:" << score << std::endl;
}

void SnakeGame::Input() {
    int input;
    struct termios oldSettings, newSettings;

    tcgetattr(STDIN_FILENO, &oldSettings);
    newSettings = oldSettings;
    newSettings.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newSettings);

    input = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldSettings);

    switch (input) {
        case 'a':
            if (dir != Direction::RIGHT)
                dir = Direction::LEFT;
            break;
        case 'd':
            if (dir != Direction::LEFT)
                dir = Direction::RIGHT;
            break;
        case 'w':
            if (dir != Direction::DOWN)
                dir = Direction::UP;
            break;
        case 's':
            if (dir != Direction::UP)
                dir = Direction::DOWN;
            break;
        case 'x':
            gameOver = true;
            break;
    }
}

void SnakeGame::Logic() {
    int prevX = tail.empty() ? snakeX : tail.front().first;
    int prevY = tail.empty() ? snakeY : tail.front().second;
    if (!tail.empty()) {
        tail.pop_back();
        tail.insert(tail.begin(), std::make_pair(snakeX, snakeY));
    }
    switch (dir) {
        case Direction::LEFT:
            snakeX--;
            break;
        case Direction::RIGHT:
            snakeX++;
            break;
        case Direction::UP:
            snakeY--;
            break;
        case Direction::DOWN:
            snakeY++;
            break;
        default:
            break;
    }

    if (snakeX >= width)
        snakeX = 0;
    else if (snakeX < 0)
        snakeX = width - 1;
    if (snakeY >= height)
        snakeY = 0;
    else if (snakeY < 0)
        snakeY = height - 1;

    for (auto const &pos : tail) {
        if (pos.first == snakeX && pos.second == snakeY) {
            gameOver = true;
            break;
        }
    }

    if (snakeX == fruitX && snakeY == fruitY) {
        score += 10;
        fruitX = rand() % width;
        fruitY = rand() % height;
        for (int i = 0; i < growthRate; ++i) {
            tail.push_back(std::make_pair(prevX, prevY));
        }
    }
}

bool SnakeGame::IsGameOver() const {
    return gameOver;
}

int SnakeGame::GetScore() const {
    return score;
}

int SnakeGame::GetSpeed() const {
    return speed;
}

unsigned char* SnakeGame::GetScreenBuffer() const {
    return screenBuffer.get();
}

void SnakeGame::SaveGame(const std::string& filename) const {
    std::ofstream file(filename);
    if (file.is_open()) {
        file << "SnakeGame\n";
        file << snakeX << " " << snakeY << "\n";
        file << fruitX << " " << fruitY << "\n";
        file << score << "\n";
        file << static_cast<int>(dir) << "\n";
        file << gameOver << "\n";
        file << speed << "\n";
        file << growthRate << "\n";
        for (const auto& pos : tail) {
            file << pos.first << " " << pos.second << "\n";
        }
    }
}

void SnakeGame::LoadGame(const std::string& filename) {
    std::ifstream file(filename);
    if (file.is_open()) {
        std::string gameType;
        file >> gameType;
        if (gameType == "SnakeGame") {
            file >> snakeX >> snakeY;
            file >> fruitX >> fruitY;
            file >> score;
            int dirValue;
            file >> dirValue;
            dir = static_cast<Direction>(dirValue);
            file >> gameOver;
            file >> speed;
            file >> growthRate;
            tail.clear();
            int posX, posY;
            while (file >> posX >> posY) {
                tail.push_back(std::make_pair(posX, posY));
            }
        }
    }
}

