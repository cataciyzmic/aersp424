{\rtf1\ansi\ansicpg1252\cocoartf2639
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww28600\viewh14680\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # Snake Game\
\
This is a simple implementation of the classic Snake game in C++. The game runs in the console and allows the player to control a snake to eat fruits and grow longer. The game ends when the snake collides with itself or the boundaries of the play area.\
\
## Features\
- Player control using the WASD keys.\
- Fruits spawn randomly on the play area for the snake to eat.\
- Score tracking.\
- Option to save and load game states for continuing games later.\
\
## Getting Started\
To compile and run the game, follow these steps:\
\
1. Clone the repository to your local machine:\
\
\
2. Compile the code using a C++ compiler. For example, using g++:\
\
\
3. Run the compiled executable:\
\
\
4. Follow the on-screen instructions to play the game.\
\
## Controls\
- Use the WASD keys to control the direction of the snake:\
  - W: Up\
  - A: Left\
  - S: Down\
  - D: Right\
- Press 'X' to exit the game.\
\
## Saving and Loading Game States\
- You can save the current game state at any time by selecting the option in the game menu.\
- To load a saved game state, select the corresponding option in the game menu and enter the filename.\
\
## Dependencies\
This game relies on standard C++ libraries and system-specific functionality. No external dependencies are required.\
\
## Contributing\
Contributions are welcome! If you have any suggestions, improvements, or bug fixes, feel free to open an issue or submit a pull request.\
\
## License\
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.\
}