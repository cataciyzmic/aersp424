#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <thread>
#include "SnakeGame.h"
#include "GameUtils.h"

int main() {
    srand(static_cast<unsigned int>(time(nullptr))); // Seed the random number generator

    SnakeGame game;

    char choice;
    std::cout << "Do you want to load a saved game? (y/n): ";
    std::cin >> choice;
    if (choice == 'y') {
        std::string filename;
        std::cout << "Enter the filename: ";
        std::cin >> filename;
        game.LoadGame(filename);
    } else {
        game.Setup();
    }

    while (!game.IsGameOver()) {
        game.Draw();
        game.Input();
        game.Logic();
        std::this_thread::sleep_for(std::chrono::milliseconds(game.GetSpeed())); // Adjust speed
    }

    std::cout << "Game Over!" << std::endl;
    std::cout << "Your Score: " << game.GetScore() << std::endl;

    char saveChoice;
    std::cout << "Do you want to save the game? (y/n): ";
    std::cin >> saveChoice;
    if (saveChoice == 'y') {
        std::string filename;
        std::cout << "Enter the filename: ";
        std::cin >> filename;
        game.SaveGame(filename);
    }

    return 0;
}
