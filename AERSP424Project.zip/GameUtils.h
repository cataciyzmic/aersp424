#ifndef GAMEUTILS_H
#define GAMEUTILS_H

#include <iostream>
#include <chrono>
#include <thread>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>

#endif // GAMEUTILS_H

